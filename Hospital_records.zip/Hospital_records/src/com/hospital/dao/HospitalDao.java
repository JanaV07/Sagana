package com.hospital.dao;



import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.util.List;  
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;  
import com.hospital.bean.*;  
  
public class HospitalDao {  
JdbcTemplate template;  
  
public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
}  
public int save(HospitalBean p){  
	
	System.out.println(p.getId());
	System.out.println(p.getAge());
    String sql="insert into PATIENTMASTER(id,name,age) values('"+p.getId()+"','"+p.getName()+"','"+p.getAge()+"')";  
    return template.update(sql);  
}  
public int update(HospitalBean p){  
    String sql="update PATIENTMASTER set name='"+p.getName()+"', age='"+p.getAge()+"' where id="+p.getId()+"";  
    return template.update(sql);  
}  
public int delete(HospitalBean p){  
    String sql="delete from PATIENTMASTER where id="+p.getId()+"";  
    return template.update(sql);  
}  
public HospitalBean getPatientById(HospitalBean p){  
    String sql="select * from PATIENTMASTER where id="+p.getId()+"";  
    System.out.println(sql);
    int id=p.getId();
    return template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<HospitalBean>(HospitalBean.class));  
}  
public HospitalBean getPatientById(int id){  
    String sql="select * from PATIENTMASTER where id=?";  
    return template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<HospitalBean>(HospitalBean.class));  
}  
public List<HospitalBean> getPatient(){  
    return template.query("select * from PATIENTMASTER",new RowMapper<HospitalBean>(){  
        public HospitalBean mapRow(ResultSet rs, int row) throws SQLException {  
        	HospitalBean h=new HospitalBean();   
            h.setId(rs.getInt(1));  
            h.setName(rs.getString(2)); 
            h.setAge(rs.getInt(3));
             
            return h;  
        }  
    });  
}


public List<HospitalBean> getPatientbyid(HospitalBean p){  
  return template.query("select * from PATIENTMASTER where id="+p.getId()+"",new RowMapper<HospitalBean>(){  
      public HospitalBean mapRow(ResultSet rs, int row) throws SQLException {  
    	  HospitalBean h=new HospitalBean();  
          h.setId(rs.getInt(1));  
          h.setName(rs.getString(2));  
          h.setAge(rs.getInt(3)); 
          
          return h;  
      }  
  });  
}



}