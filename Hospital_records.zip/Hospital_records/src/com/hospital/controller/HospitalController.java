package com.hospital.controller;

import java.util.ArrayList;  
import java.util.List;  

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;  
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.servlet.ModelAndView;  


import com.hospital.bean.*;  
import com.hospital.dao.*;  
@Controller  
public class HospitalController {  
    @Autowired  
    HospitalDao dao;
    
    
    
    
    
    
   
    @RequestMapping("/Create")  
    public ModelAndView showform(){  
    	System.out.println("sahana");
        return new ModelAndView("Create","command",new HospitalBean());  
    }  
    
    
    
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public ModelAndView save(HospitalBean hb){  
    	System.out.println("sahana");
        dao.save(hb);  
        return new ModelAndView("redirect:/retrieveAll");  
    }  
    
    @RequestMapping("/retrieveAll")  
    public ModelAndView viewPatients(){  
        List<HospitalBean> list=dao.getPatient();  
        return new ModelAndView("RetrieveAll","list",list);  
    } 
    
    
    @RequestMapping("/Retrieve")  
    public ModelAndView showretrive(){  
    	System.out.println("sahana");
        return new ModelAndView("Retrieve","command",new HospitalBean());  
    }
    
    
    @RequestMapping(value="/retrieve",method = RequestMethod.POST)  
    public ModelAndView viewPatient(@ModelAttribute("hospital") HospitalBean hb){  
    	
    	    	System.out.println(hb.getId());
    	    	
    	    	List<HospitalBean> list=dao.getPatientbyid(hb);
    	    	return new ModelAndView("RetrieveAll","list",list);  
    } 
    
    
    
    @RequestMapping("/delete")  
    public ModelAndView delete(){  
    	System.out.println("sahana");
        return new ModelAndView("Delete","command",new HospitalBean());  
    }  
    
    
    
    @RequestMapping(value="/Deletee",method = RequestMethod.POST)  
    public ModelAndView delete(@ModelAttribute("hospital") HospitalBean hb){  
        dao.delete(hb);  
        return new ModelAndView("redirect:/retrieveAll");  
    }  
    
    
    @RequestMapping("/Edit")  
    public ModelAndView Edit(){  
    	System.out.println("sahana");
        return new ModelAndView("Edit","command",new HospitalBean());  
    }  
    
    
   
    
    
    
    @RequestMapping(value="/editee",method = RequestMethod.POST)  
    public ModelAndView edite(@ModelAttribute("hospital") HospitalBean hb){  
    	System.out.println("sahana");
    	int id=hb.getId();
    	HospitalBean hdb=dao.getPatientById(id);
    	System.out.println("sdfds");
        return new ModelAndView("editForm","command",hdb);  
    }
    
    
    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public ModelAndView editsave(@ModelAttribute("hb") HospitalBean hb){  
        dao.update(hb);  
        return new ModelAndView("redirect:/retrieveAll");  
    }  
    
   /* @RequestMapping("/find")  
    public ModelAndView showfind(){  
        return new ModelAndView("find","command",new HospitalBean());  
    }  */
    
  
}  