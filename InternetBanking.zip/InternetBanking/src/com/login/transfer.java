package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class transfer
 */
@WebServlet("/transfer")
public class transfer extends HttpServlet {

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession hs = request.getSession();
		String uname = hs.getAttribute("uname").toString();
			System.out.println(uname);
		String destinationaccount = request.getParameter("daccount");

		int destaccount = Integer.parseInt(destinationaccount.substring(8));
		String amont = request.getParameter("damount");
		int amount = Integer.parseInt(amont);

		String sql1 = "select amount from xbbl5sl_account where name='"
				+ uname + "'";
		String sql2 = "select amount from xbbl5sl_account where acc="
				+ destaccount;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:inatp02", "shobana",
					"shobana");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql1);
			System.out.println("here");
			if (rs.next()) {
				int samount = rs.getInt("amount");
				if (samount > amount) {
					samount = samount - amount;
					sql1 = "update xbbl5sl_account set amount='" + samount
							+ "' where name='" + uname + "'";
					System.out.println("here");
					st.executeQuery(sql1);
					ResultSet rs2 = st.executeQuery(sql2);
					if (rs2.next()) {
						int damount = rs2.getInt("amount");
						damount = damount + amount;
						sql2 = "update xbbl5sl_account set amount='" + damount
								+ "' where acc="+ destaccount;
						System.out.println("here");
						st.executeQuery(sql2);
						out.println("<script>alert('Transferred Succesfully');</script>");
						response.sendRedirect("Loggedin.jsp");
					}

				} else {
					out.println("<script>alert('Insufficient Balance');</script>");
					response.sendRedirect("Money.jsp");
				}

			}

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

	}

}
