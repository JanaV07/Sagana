package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String name=request.getParameter("uname");
		String pass=request.getParameter("pass");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:inatp02", "shobana",
					"shobana");
			Statement st=conn.createStatement();
			String sql="select * from xbbl5sl_account where name='"+name+"' and password='"+pass+"'";
			System.out.println(sql);
			ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				HttpSession hs=request.getSession();
				hs.setAttribute("uname", name);
				hs.setAttribute("pass", pass);
				
				//RequestDispatcher rd=request.getRequestDispatcher("Loggedin.jsp");
				//rd.forward(request, response);
				response.sendRedirect("Loggedin.jsp");
			}
			else{
				RequestDispatcher rd=request.getRequestDispatcher("LogFirst.html");
				rd.forward(request, response);
			}
			    
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}


}
