package com.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Admin
 */
@WebServlet("/admin")
public class Admin extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("aname");
		String pass=request.getParameter("pass");
		
		HttpSession hs=request.getSession();
		hs.setAttribute("aname", name);
		hs.setAttribute("pass", pass);
		RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
		rd.forward(request, response);
		
		/*PrintWriter out=response.getWriter();
		String sname="sahana";
		String spass="1695";
		String jname="jana";
		String jpass="7693";	
		if((name==sname && pass==spass) || (name==jname && pass==jpass))
		{
		
		
		
		}
		else
		{
		
			out.println("<script>alert('Access Denied')</script>");
			RequestDispatcher rd=request.getRequestDispatcher("FirstPage.html");
			rd.forward(request, response);
			*/
		
		
	}

}
