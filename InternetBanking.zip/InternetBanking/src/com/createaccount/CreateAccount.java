package com.createaccount;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CA")
public class CreateAccount extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		String name=request.getParameter("c_name");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String cpassword=request.getParameter("cpassword");
		if(password.compareTo(cpassword)==0){
		String address=request.getParameter("address");
		String mobile=request.getParameter("con_number");
		String amount=request.getParameter("depamount");
			System.out.println(name);
			System.out.println(email);
		int num=0;
		String sq="select * from  xbbl5sl_account where acc=(select max(acc)  from xbbl5sl_account)";
		int year = Calendar.getInstance().get(Calendar.YEAR);
		System.out.println(year);
		
		String an="RBI"+year;
		System.out.println(an);
		int k=0;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:inatp02", "shobana",
					"shobana");
		
			Statement st=conn.createStatement();
			ResultSet rs= st.executeQuery(sq);
			if(rs.next())
			
			k=Integer.parseInt(rs.getString(1).toString());
			k++;
			String kf=String.format("%08d",k);
			an=an+kf;
			System.out.println(an);
			num=Integer.parseInt(kf);
			String sql="insert into xbbl5sl_account values('"+num+"','"+name+"','"+email+"','"+password+"','"+address+"','"+mobile+"','"+amount+"')";
			System.out.println(sql);
			st.execute(sql);
			out.println("<script>alert('Successfully Created');</script>");
			RequestDispatcher rd=request.getRequestDispatcher("FirstPage1.html");
			rd.forward(request, response);
			
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		out.println("<script>alert('Account Not Created');</script>");
		response.sendRedirect("Register.jsp");
		}
		else
			out.println("<h1>Password not match.Enter the same password</h1>");
		
	}

}
