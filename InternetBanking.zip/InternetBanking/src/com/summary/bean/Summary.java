package com.summary.bean;

public class Summary {
private static int Account;
private static String Name;
public static int getAccount() {
	return Account;
}
public static void setAccount(int account) {
	Account = account;
}
public static String getName() {
	return Name;
}
public static void setName(String name) {
	Name = name;
}
public static String getEmail() {
	return Email;
}
public static void setEmail(String email) {
	Email = email;
}
public static String getPassword() {
	return Password;
}
public static void setPassword(String password) {
	Password = password;
}
public static String getAddress() {
	return Address;
}
public static void setAddress(String address) {
	Address = address;
}
public static String getMobile() {
	return Mobile;
}
public static void setMobile(String mobile) {
	Mobile = mobile;
}
public static int getAmount() {
	return Amount;
}
public static void setAmount(int amount) {
	Amount = amount;
}
private static String Email;
private static String Password;
private static String Address;
private static String Mobile;
private static int Amount;

}
