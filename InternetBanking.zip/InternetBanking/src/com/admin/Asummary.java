package com.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.summary.bean.Summary;

/**
 * Servlet implementation class Asummary
 */
@WebServlet("/asummary")
public class Asummary extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String name=request.getParameter("uname");
		String pass=request.getParameter("pass");
		String uacc=request.getParameter("uaccount");
		int account=Integer.parseInt(uacc.substring(8));
		System.out.println(account);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:inatp02", "shobana",
					"shobana");
			Statement st=conn.createStatement();
			String sql="select * from xbbl5sl_account where acc="+account;
			System.out.println(sql);
			ResultSet rs=st.executeQuery(sql);
			Summary sum=new Summary();
			if(rs.next()){
			sum.setAccount(Integer.parseInt(rs.getString("acc")));
			sum.setName(rs.getString("name"));
			sum.setEmail(rs.getString("email"));
			sum.setPassword(rs.getString("password"));
			sum.setAddress(rs.getString("address"));
			sum.setMobile(rs.getString("mobile"));
			sum.setAmount(Integer.parseInt(rs.getString("amount")));
			
			response.sendRedirect("getSummary.jsp");
			}
		
	}
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	
	}
}
