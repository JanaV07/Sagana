package com.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.summary.bean.Summary;
import com.admin.Asummary;

/**
 * Servlet implementation class getSummary
 */
@WebServlet("/getSummary")
public class getSummary extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		Summary k=new Summary();
	
		System.out.println(k.getName());
		System.out.println(k.getAccount());
		System.out.println(k.getAddress());
		
		
	}

	

}
